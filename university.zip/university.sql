create DATABASE University;
use University;
CREATE TABLE Students(
    student_id INT PRIMARY KEY,
    student_name VARCHAR(100),
    gender VARCHAR(10),
    programme VARCHAR(50),
    year_of_study INT,
    age INT,
    marks INT,
    town VARCHAR(50)

);
insert into Students VALUES
    (101,'Sara Nakato','Female','BSIT',1,19,78,'Mukono'),
    (102,'John Kato','Male','DIT',2,22,65,'Kampala'),
    (103,'Mary Achieng','Female','DIT',3,24,88,'Jinja'),
    (104,'David Ouma','Male','BSE',1,20,54,'Mukono'),
    (105,'Peter Ssenyonga','Male','BSIT',2,23,72,'Kampala'),
    (106,'Grace Namusoke','Female','DIT',1,20,91,'Entebbe'),
    (107,'Ruth Nakanwagi','Female','BSIT',2,21,83,'Mukono'),
    (109,'Samuel Mugisha','Male','DIT',3,24,69,'Kampala'),
    (110,'Esther Atim','Female','BSE',1,19,76,'Gulu');
    SELECT * From Students;
    DESCRIBE Students;
    SELECT student_name,programme,marks FROM Students;
    select student_name,town FROM Students;
    select * FROM Students WHERE year_of_study=1;
    select student_name,marks FROM Students WHERE programme='DIT';
    SELECT student_name,age FROM Students;
SELECT * FROM Students WHERE programme='BSIT';
SELECT * FROM Students WHERE marks>=70;
SELECT * FROM Students WHERE town='Mukono';
SELECT * FROM Students WHERE gender='Female';
SELECT * FROM Students WHERE programme='BSIT' and marks>75;
SELECT * FROM Students WHERE town='Mukono' OR town='Kampala';
SELECT * FROM Students WHERE gender='female' AND year_of_study=1;
SELECT * FROM Students WHERE marks BETWEEN 60 AND 80;
SELECT * FROM Students WHERE programme<>'BSE';
SELECT * FROM Students ORDER BY marks DESC;
SELECT * FROM Students ORDER BY marks ASC;
SELECT * FROM Students WHERE programme='BSIT' ORDER BY marks DESC;
SELECT * FROM Students WHERE gender='Female' AND programme='BSIT' AND marks>=80;
SELECT * FROM Students WHERE year_of_study=2 AND marks>70;
SELECT * FROM Students WHERE (town='Mukono'AND marks<60) OR(town='Jinja'AND marks>80);

##
the mistakes i discovered while running my querries included failure to use and recognise the commas,quotation marks 
the challenge quesations were tricky
in an institution like a school,filtering of data is key because it provides specific information to specific people as well as helping in the data integrity and confidentiality of induvifual

DESCRIBE Students;
SELECT* from Students order by programme DESC;

CREATE VIEW male_students
 as select* from students where gender ='males';
 DESCRIBE Students;
 CREATE VIEW  XYZ 
 AS select* from Students WHERE PROGRAMME not in ('BSIT','BIT')

 ##i)VIEW TO RETREIVE FEMALE Students
 CREATE VIEW viewone 
 as select *from Students where gender= 'female';
 DESCRIBE Students;

 ## ii)NOT OFFERING  BSIT OR DIT
 create VIEW Viewtwo 
 as select*FROM Students WHERE programme NOT IN('DIT','BSIT');

 ##iii)view three and increase all student marks by 5,and new column shall be marks_change
 create VIEW viewthree
 AS select*,(marks+5)AS Marks_change FROM Students;

 ##iv)student whosee names start with letter S
CREATE View viewfour AS
SELECT*from Students WHERE student_name like 'S%';

##v)viewfive number of students offering DIT
CREATE VIEW viewfive as 
SELECT COUNT (*)AS number_of_DIT_students FROM Students where programme='DIT'

##vi)viewsix and stuents in a cronological ORDER 
CREATE VIEW  viewsix 
as SELECT *FROM Students ORDER BY marks ASC;

## vii)viewseven_ male +BSIT
create view viewseven as SELECT * from Students WHERE gender='male'AND programme='BSIT';

##viii) best to worst based on programmes(BSIT first and DIT last)
create view vieweight as 
SELECT *  from Students ORDER BY FIELD (programme,'BSCS','BSIT','BIT','DIT'), marks DESC; 


##ix) add  a NIN column
ALTER table students add COLUMN NIN VARCHAR(20);

## X)RENAME student_id TO student_identification
ALTER table Students RENAME column student_id to Students_identification; 

##xi)delete lasdt record
DELETE FROM Students ORDER BY Student_identification DESC limit 1;
DESCRIBE Students;
##xii)clustering
select programme, count(*) as total_students FROM Students group by programme;